package GUI;

public enum OrderMode {
    ASCD, DESC, NORM;
}
